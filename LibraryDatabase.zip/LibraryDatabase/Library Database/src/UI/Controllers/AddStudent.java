package UI.Controllers;

import Database.DatabaseHandler;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;


public class AddStudent implements Initializable {

    public TextField getID;
    public TextField getName;
    public TextField getEmail;
    public DatabaseHandler handler;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //Instantiates DatabaseHandler
        try {
            handler = DatabaseHandler.getInstance();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void addStudent(ActionEvent actionEvent) {
        //Method to add student to the database
        String n = getName.getText();
        String i = getID.getText();
        String email = getEmail.getText();
        //Checks if textField is empty
        boolean flag = n.isEmpty() || i.isEmpty() || email.isEmpty();
        boolean length = n.length() > 200 || i.length() > 200 || email.length() > 200;
        if(flag) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter all fields");
            alert.setHeaderText(null);
            alert.showAndWait();
            return;
        }
        //Checks if the textFIeld has more than 200 characters
        if(length) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter 200 or less characters");
            alert.setHeaderText(null);
            alert.showAndWait();
            return;
        }
        //Puts values into database
        String st = "INSERT INTO STUDENT VALUES (" +
                "'" + i + "'," +
                "'" + n + "'," +
                "'" + email + "'" + ")";
        System.out.println(st);
        if(handler.execAction(st)) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Saved");
            alert.setHeaderText(null);
            alert.showAndWait();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Error with inputting data");
            alert.setHeaderText(null);
            alert.showAndWait();
            return;
        }
        getID.clear();
        getName.clear();
        getEmail.clear();
    }
}
