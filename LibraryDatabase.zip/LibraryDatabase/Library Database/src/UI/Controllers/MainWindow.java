package UI.Controllers;

import Database.DatabaseHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MainWindow implements Initializable {

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //Sets up program
        System.out.println("Runs when window opens");
        DatabaseHandler main = new DatabaseHandler();
        BorrowBook b = new BorrowBook();
        ReturnBook r = new ReturnBook();
        b.ID.clear();
        r.ID.clear();
    }
    void loadWindow(String location, String title) {
        //Method to allow multiple windows to open up
        try{
            Parent parent = FXMLLoader.load(getClass().getResource(location));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addStudent(ActionEvent actionEvent) {
        //Loads addStudent window
        loadWindow("../Layouts/addStudent.fxml", "Add Student");
    }

    public void Login(ActionEvent actionEvent) {
        //Loads Login window
        loadWindow("../Layouts/Login.fxml", "Login");
    }

    public void addBook(ActionEvent actionEvent) {
        //Loads addBook window
        loadWindow("../Layouts/addBook.fxml", "Add Book");
    }

    public void showStudents(ActionEvent actionEvent) {
        //Loads the showStudents window
        loadWindow("../Layouts/showStudents.fxml", "Student List");
    }

    public void showBooks(ActionEvent actionEvent) {
        //Loads the showBooks window
        loadWindow("../Layouts/showBooks.fxml", "Book List");
    }

    public void borrowBook() {
        //Loads the borrowBook window
        loadWindow("../Layouts/borrowBook.fxml", "Borrow Book");
    }
}
