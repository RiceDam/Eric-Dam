package Network;
import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;
import com.esotericsoftware.kryonet.Server;

import java.io.IOException;
import java.util.Date;

public class OrderServer extends Listener {
    static public Server server = new Server();
    static public int udpPort = 16384, tcpPort = 16384;
    public static Connection c;

    public OrderServer() throws Exception{
        //Constructor
        server.getKryo().register(PacketMessage.class);
    }

    public void connected(Connection c) {
        //Method that runs when client is connected
        this.c = c;
        System.out.println("Received connection from " + c.getRemoteAddressTCP().getHostString());
    }

    public void received(Connection c, Object p) {
        //Don't expect to receive anything
    }

    public void disconnected(Connection c) {
        //Method that runs when client disconnects
        System.out.println("Client was disconnected");
    }
}
