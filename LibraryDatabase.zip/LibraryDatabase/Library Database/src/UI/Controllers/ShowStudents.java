package UI.Controllers;

import Database.DatabaseHandler;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ShowStudents implements Initializable {
    public TableView stuTable;

    public static class Student {
        private final SimpleStringProperty id;
        private final SimpleStringProperty name;
        private final SimpleStringProperty email;

        Student(String id, String name, String email) {
            this.id = new SimpleStringProperty(id);
            this.name = new SimpleStringProperty(name);
            this.email = new SimpleStringProperty(email);
        }

        public String getName() {
            return name.get();
        }
        public String getID() {
            return id.get();
        }
        public String getEmail() {
            return email.get();
        }
    }
    public ObservableList<Student> students = FXCollections.observableArrayList();
    public TableColumn stuID;
    public TableColumn stuName;
    public TableColumn stuEmail;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initiCol();
        try {
            loadData();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadData() throws SQLException {
        DatabaseHandler handler = DatabaseHandler.getInstance();
        String qu = "SELECT * FROM STUDENT";
        ResultSet rs = handler.execQuery(qu);
        while(rs.next()) {
            String id = rs.getString("id");
            String name = rs.getString("name");
            String email = rs.getString("email");

            students.add(new Student(id,name,email));
        }
        stuTable.getItems().setAll(students);
    }

    private void initiCol() {
        stuID.setCellValueFactory(new PropertyValueFactory<>("ID"));
        stuName.setCellValueFactory(new PropertyValueFactory<>("Name"));
        stuEmail.setCellValueFactory(new PropertyValueFactory<>("Email"));
    }
}
