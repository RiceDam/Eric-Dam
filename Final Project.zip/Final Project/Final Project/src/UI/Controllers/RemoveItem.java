package UI.Controllers;

import Database.DatabaseHandler;
import Order.Food;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class RemoveItem implements Initializable {
    public TableColumn menuName;
    public TableColumn menuPrice;
    public Button remButton;
    public Label name;
    public Label price;
    public TableView menuTable;
    public ObservableList<Food> menu = FXCollections.observableArrayList();
    public Button retButton;

    void loadWindow(String location, String title) {
        //Method to load other windows
        try{
            Parent parent = FXMLLoader.load(getClass().getResource(location));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void tableClick(MouseEvent mouseEvent) {
        //When section of table clicked, displays information on labels
        try {
            int index = menuTable.getSelectionModel().getSelectedIndex();
            name.setText(menu.get(index).getName());
            price.setText(Double.toString(menu.get(index).getPrice()));
        }
        catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("Please select an item in the table");
        }
    }

    private void loadData() throws SQLException {
        //Loads items from database
        DatabaseHandler handler = DatabaseHandler.getInstance();
        String qu = "SELECT * FROM MENU";
        ResultSet rs = handler.execQuery(qu);
        while (rs.next()) {
            String name = rs.getString("name");
            String price = rs.getString("price");
            menu.add(new Food(name, Double.parseDouble(price)));
        }
        menuTable.getItems().setAll(menu);
    }

    public void removeItem(ActionEvent actionEvent) throws SQLException{
        //Removes item from database
        if(menuTable.getItems().size() > 0) {
            ObservableList<Food> temp = FXCollections.observableArrayList();
            int index = menuTable.getSelectionModel().getSelectedIndex();
            DatabaseHandler handler = DatabaseHandler.getInstance();
            String qu = "DELETE FROM MENU" + " WHERE name = ?";
            try (PreparedStatement stmt = handler.conn.prepareStatement(qu)) {
                stmt.setString(1, name.getText());
                stmt.executeUpdate();
                String qu1 = "SELECT * FROM MENU";
                ResultSet rs = handler.execQuery(qu1);
                while (rs.next()) {
                    String name = rs.getString("name");
                    String price = rs.getString("price");
                    temp.add(new Food(name, Double.parseDouble(price)));
                }
                menuTable.getItems().setAll(temp);
                name.setText("");
                price.setText("");
                menu.remove(index);
            }
        }
        else {
            System.out.println("There are no items on the menu");
        }
    }

    private void initialCol() {
        //Initializes table columns
        menuName.setCellValueFactory(new PropertyValueFactory<>("Name"));
        menuPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initialCol();
        try {
            loadData();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void returnToMenu(ActionEvent actionEvent) {
        //Return to main menu window
        loadWindow("../Layouts/menuWindow.fxml", "Menu");
        Stage stage = (Stage) retButton.getScene().getWindow();
        stage.close();
    }
}
