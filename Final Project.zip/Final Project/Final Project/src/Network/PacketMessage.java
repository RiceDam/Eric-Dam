package Network;

public class PacketMessage {
    //Packet class that gets sent
    public String message;
}
