package Database;

import org.apache.derby.client.am.SqlException;

import javax.swing.*;
import java.sql.*;

public class DatabaseHandler {
    private static DatabaseHandler handler = null;
    private static final String DB_url = "jdbc:derby:database/forum;create=true";
    public static Connection conn = null;
    private static Statement stat = null;

    public DatabaseHandler() {
        //Sets up Database
        createConnection();
        createStudentTable();
        createBookTable();
    }

    public static DatabaseHandler getInstance() throws SQLException {
        //Creates instance of Database handler
        if(handler == null) {
            handler = new DatabaseHandler();
        }
        return handler;
    }

    private void createConnection() {
        //Connects to database
        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
            conn = DriverManager.getConnection(DB_url);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createStudentTable() {
        //Creates the STUDENT table in the database if it doesn't exist
        String TABLE_NAME = "STUDENT";
        try {
            stat = conn.createStatement();
            DatabaseMetaData dmn = conn.getMetaData();
            ResultSet tables = dmn.getTables(null,null,TABLE_NAME,null);
            if(tables.next()) {
                System.out.println("Table " + TABLE_NAME + " already exists");
            }
            else{
                String statement = "CREATE TABLE " + TABLE_NAME + "("
                        + "id varchar (200) primary key, \n"
                        + "name varchar (200), \n"
                        + "email varchar( 200))";
                System.out.println(statement);
                stat.execute(statement);
            }
        }
        catch (SQLException e) {
            System.out.println(e.getMessage() + "setting up database");
        }
    }

    private void createBookTable() {
        //Creates the BOOK table in the database if it doesn't exist
        String TABLE_NAME = "BOOK";
        try {
            stat = conn.createStatement();
            DatabaseMetaData dmn = conn.getMetaData();
            ResultSet tables = dmn.getTables(null,null,TABLE_NAME,null);
            if(tables.next()) {
                System.out.println("Table " + TABLE_NAME + " already exists");
            }
            else{
                String statement = "CREATE TABLE " + TABLE_NAME + "("
                        + "name varchar (200) primary key, \n"
                        + "author varchar (200), \n"
                        + "borrower varchar(200))";
                System.out.println(statement);
                stat.execute(statement);
            }
        }
        catch (SQLException e) {
            System.out.println(e.getMessage() + "setting up database");
        }
    }

    public ResultSet execQuery(String query) {
        //Executes the query which returns a result set
        ResultSet resultSet;
        try{
            stat = conn.createStatement();
            resultSet = stat.executeQuery(query);
        }
        catch (SQLException e) {
            System.out.println("Exception at Execute query");
            return null;
        }
        return resultSet;
    }

    public boolean execAction(String qu) {
        //Executes action that returns a boolean
        try {
            stat = conn.createStatement();
            stat.execute(qu);
            return true;
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            System.out.println("Exception at execQuery" + e.getLocalizedMessage());
            return false;
        }
    }

    public void deleteTable(String s) {
        //Deletes a table depending on the string inserted
        String drop = "DROP TABLE " + s.toUpperCase();
        execAction(drop);
        System.out.println("Table deleted");
    }
}
