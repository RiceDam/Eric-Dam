package Network;

import UI.Controllers.ClientController;
import com.esotericsoftware.kryonet.Client;
import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class OrderClient extends Listener {
    static public Client client = new Client();
    static public String ip = "localhost";
    static public int udpPort = 16384, tcpPort = 16384;
    static public boolean messageReceived = false;
    static public String message = "";
    static private ArrayList<String> messages = new ArrayList<>();
    static public ClientController controller;

    public OrderClient(ClientController clientController) throws Exception{
        //Constructor
        client.getKryo().register(PacketMessage.class);
        controller = clientController;
    }

    public void received(Connection c, Object p) {
        //Method that runs when packet message received
        if(p instanceof  PacketMessage) {
            PacketMessage packet = (PacketMessage) p;
            System.out.println("Received  message from host: " + packet.message);
            message = packet.message;
            messageReceived = true;
            Platform.runLater(() ->{
                controller.addOrder(message);
            });
        }
    }
}
