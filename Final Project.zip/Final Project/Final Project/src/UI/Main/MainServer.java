package UI.Main;

import UI.Controllers.ServerController;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class MainServer extends Application {
    @Override
    public void start(final Stage primaryStage) throws Exception{
        //Loads Server window
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(MainServer.class.getResource("../Layouts/serverWindow.fxml"));
        Parent root = loader.load();
        primaryStage.setTitle("Server");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
        Platform.setImplicitExit(true);
        final ServerController controller = loader.getController();
        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                Platform.exit();
                System.out.println("Program Closing");
                controller.orderServer.server.stop();
                primaryStage.close();
            }
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
