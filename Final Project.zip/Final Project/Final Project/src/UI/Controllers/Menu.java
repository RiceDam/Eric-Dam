package UI.Controllers;

import Database.DatabaseHandler;
import Order.Food;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Menu implements Initializable {
    public TableColumn menuName;
    public TableView menuTable;
    public TableColumn menuPrice;
    public ObservableList<Food> menu = FXCollections.observableArrayList();
    public Button addButton;
    public Button removeButton;

    void loadWindow(String location, String title) {
        //Loads a new window
        try{
            Parent parent = FXMLLoader.load(getClass().getResource(location));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadData() throws SQLException {
        //Loads item into the table view
        DatabaseHandler handler = DatabaseHandler.getInstance();
        String qu = "SELECT * FROM MENU";
        ResultSet rs = handler.execQuery(qu);
        while (rs.next()) {
            String name = rs.getString("name");
            String price = rs.getString("price");
            menu.add(new Food(name, Double.parseDouble(price)));
        }
        menuTable.getItems().setAll(menu);
    }

    private void initialCol() {
        //Initializes table columns
        menuName.setCellValueFactory(new PropertyValueFactory<>("Name"));
        menuPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));
    }

    public void addWindow(ActionEvent actionEvent) {
        //Loads up the add item window
        loadWindow("../Layouts/addItemWindow.fxml", "Add Item");
        Stage stage = (Stage) addButton.getScene().getWindow();
        stage.close();
    }

    public void removeWindow(ActionEvent actionEvent) {
        //Loads up the remove item window
        loadWindow("../Layouts/removeItemWindow.fxml", "Remove Item");
        Stage stage = (Stage) removeButton.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initialCol();
        try {
            loadData();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
