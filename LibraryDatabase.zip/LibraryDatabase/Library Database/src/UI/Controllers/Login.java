package UI.Controllers;

import Database.DatabaseHandler;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Login {
    public TextField getID;
    public Button logButton;
    MainWindow login = new MainWindow();

    public void Login(ActionEvent actionEvent) throws SQLException {
        try {
            DatabaseHandler handler = DatabaseHandler.getInstance();
            Boolean exists = false;
            String id = getID.getText();
            String qu = "SELECT * FROM STUDENT";
            ResultSet rs = handler.execQuery(qu);
            while (rs.next()) {
                String ID = rs.getString("id");
                if (id.equals(ID)) {
                    exists = true;
                    BorrowBook temp = new BorrowBook();
                    temp.ID.add(id);
                    break;
                }
            }
            if (!exists) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Please enter an existing ID");
                alert.setHeaderText(null);
                alert.showAndWait();
                return;
            }
            else {
                login.borrowBook();
                Stage stage = (Stage) logButton.getScene().getWindow();
                stage.close();
            }
        }
        catch(SQLException e) {
            e.printStackTrace();
        }
    }
}
