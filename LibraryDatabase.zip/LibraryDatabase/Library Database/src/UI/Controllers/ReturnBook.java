package UI.Controllers;

import Database.DatabaseHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class ReturnBook implements Initializable {
    public Label authorDisplay;
    public Label nameDisplay;
    public Label idDisplay;
    public TableColumn authorName;
    public TableColumn bookName;
    public TableView bookTable;
    static ArrayList<String> ID = new ArrayList<>();
    MainWindow main = new MainWindow();

    public ObservableList<BorrowBook.availableBooks> books = FXCollections.observableArrayList();
    public Button backButton;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //Sets up the returnBook window
        idDisplay.setText(ID.get(ID.size()-1));
        initialCol();
        try {
            loadData();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadData() throws SQLException {
        //Sets up the table in the returnBook window
        DatabaseHandler handler = DatabaseHandler.getInstance();
        String qu = "SELECT * FROM BOOK";
        ResultSet rs = handler.execQuery(qu);
        while(rs.next()) {
            String name = rs.getString("name");
            String author = rs.getString("author");
            String borrower = rs.getString("borrower");
            if(borrower.equals(idDisplay.getText())) {
                books.add(new BorrowBook.availableBooks(name, author));
            }
        }
        bookTable.getItems().setAll(books);
    }

    private void initialCol() {
        //Sets the table values
        bookName.setCellValueFactory(new PropertyValueFactory<>("Name"));
        authorName.setCellValueFactory(new PropertyValueFactory<>("Author"));
    }

    public void returnBook(ActionEvent actionEvent) throws Exception{
        //Method to return the book that the user borrowed
        ObservableList<BorrowBook.availableBooks> temp = FXCollections.observableArrayList();
        int index = bookTable.getSelectionModel().getSelectedIndex();
        DatabaseHandler handler = DatabaseHandler.getInstance();
        //Updates the values in the database
        String qu = "UPDATE BOOK" + " SET borrower = ?" + " WHERE name = ?";
        try (PreparedStatement stmt = handler.conn.prepareStatement(qu)) {
            stmt.setString(1, "none");
            stmt.setString(2, nameDisplay.getText());
            stmt.executeUpdate();
            String qu1 = "SELECT * FROM BOOK";
            ResultSet rs = handler.execQuery(qu1);
            while(rs.next()) {
                String name = rs.getString("name");
                String author = rs.getString("author");
                String borrower = rs.getString("borrower");
                if(borrower.equals(idDisplay.getText())) {
                    temp.add(new BorrowBook.availableBooks(name, author));
                }
            }
            //Updates the tableview
            bookTable.getItems().setAll(temp);
            nameDisplay.setText("");
            authorDisplay.setText("");
            books.remove(index);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        catch(ArrayIndexOutOfBoundsException e) {
            //IF the user did not select a book and presses the return button, give error
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please select a book to return");
            alert.setHeaderText(null);
            alert.showAndWait();
            return;
        }
    }

    public void tableClick(MouseEvent mouseEvent) throws ArrayIndexOutOfBoundsException{
        //Sets the label values to the book selected in the tableview
        try {
            int index = bookTable.getSelectionModel().getSelectedIndex();
            nameDisplay.setText(books.get(index).getName());
            authorDisplay.setText(books.get(index).getAuthor());
        }
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Please select a book from the table");
        }
    }

    public void goBack(ActionEvent actionEvent) {
        //Goes back to the borrowBook window
        main.loadWindow("../Layouts/borrowBook.fxml", "Borrow Book");
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }
}
