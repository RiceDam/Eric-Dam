package UI.Controllers;

import Database.DatabaseHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MainWindow implements Initializable {

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("Runs when window opens");
        DatabaseHandler main = new DatabaseHandler();
        BorrowBook b = new BorrowBook();
        ReturnBook r = new ReturnBook();
        b.ID.clear();
        r.ID.clear();
    }
    void loadWindow(String location, String title) {
        try{
            Parent parent = FXMLLoader.load(getClass().getResource(location));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addStudent(ActionEvent actionEvent) {
        loadWindow("../Layouts/addStudent.fxml", "Add Student");
    }

    public void Login(ActionEvent actionEvent) {
        loadWindow("../Layouts/Login.fxml", "Login");
    }

    public void addBook(ActionEvent actionEvent) {
        loadWindow("../Layouts/addBook.fxml", "Add Book");
    }

    public void showStudents(ActionEvent actionEvent) {
        loadWindow("../Layouts/showStudents.fxml", "Student List");
    }

    public void showBooks(ActionEvent actionEvent) {
        loadWindow("../Layouts/showBooks.fxml", "Book List");
    }

    public void borrowBook() {
        loadWindow("../Layouts/borrowBook.fxml", "Borrow Book");
    }
}
