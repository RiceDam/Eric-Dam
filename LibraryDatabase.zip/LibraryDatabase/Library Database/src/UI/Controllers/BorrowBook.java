package UI.Controllers;

import Database.DatabaseHandler;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class BorrowBook implements Initializable {
    public TableView bookTable;
    public TableColumn bookName;
    public TableColumn authorName;
    public Label idDisplay;
    static ArrayList<String> ID = new ArrayList<>();
    public Label nameDisplay;
    public Label authorDisplay;
    public MainWindow main = new MainWindow();
    public Button retButton;
    ReturnBook ret = new ReturnBook();

    public void tableClick(MouseEvent mouseEvent) throws ArrayIndexOutOfBoundsException {
        //Selecting a row in the table changes respective labels
        try {
            int index = bookTable.getSelectionModel().getSelectedIndex();
            nameDisplay.setText(books.get(index).getName());
            authorDisplay.setText(books.get(index).getAuthor());
        }
        catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("Please select a book from the table");
        }
    }

    public void borrow(ActionEvent actionEvent) throws Exception {
        //Updates the borrower section of the BOOK table in the database
        ObservableList<availableBooks> temp = FXCollections.observableArrayList();
        int index = bookTable.getSelectionModel().getSelectedIndex();
        DatabaseHandler handler = DatabaseHandler.getInstance();
        String qu = "UPDATE BOOK" + " SET borrower = ?" + " WHERE name = ?";
        try (PreparedStatement stmt = handler.conn.prepareStatement(qu)) {
            stmt.setString(1, idDisplay.getText());
            stmt.setString(2, nameDisplay.getText());
            stmt.executeUpdate();
            String qu1 = "SELECT * FROM BOOK";
            ResultSet rs = handler.execQuery(qu1);
            while(rs.next()) {
                String name = rs.getString("name");
                String author = rs.getString("author");
                String borrower = rs.getString("borrower");
                if(borrower.equals("none")) {
                    temp.add(new availableBooks(name, author));
                }
            }
            //Updates the tableview
            bookTable.getItems().setAll(temp);
            nameDisplay.setText("");
            authorDisplay.setText("");
            books.remove(index);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        catch (ArrayIndexOutOfBoundsException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please select a book to borrow");
            alert.setHeaderText(null);
            alert.showAndWait();
            return;
        }
    }

    public void returnBook(ActionEvent actionEvent) {
        //Loads the return book window
        main.loadWindow("../Layouts/returnBook.fxml", "Return Book");
        Stage stage = (Stage) retButton.getScene().getWindow();
        stage.close();
    }

    public static class availableBooks {
        private final SimpleStringProperty name;
        private final SimpleStringProperty author;

        availableBooks(String name, String author) {
            this.name = new SimpleStringProperty(name);
            this.author = new SimpleStringProperty(author);
        }

        public String getName() {
            return name.get();
        }

        public void setName(String name) {
            this.name.set(name);
        }

        public String getAuthor() {
            return author.get();
        }

        public void setAuthor(String author) {
            this.author.set(author);
        }
    }
    public ObservableList<availableBooks> books = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //Gets the ID of the user
        ret.ID.add(ID.get(ID.size()-1));
        idDisplay.setText(ID.get(ID.size()-1));
        initialCol();
        try {
            loadData();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadData() throws SQLException {
        //Gets information from the BOOK table and displays it onto the tableview if the book can be borrowed
        DatabaseHandler handler = DatabaseHandler.getInstance();
        String qu = "SELECT * FROM BOOK";
        ResultSet rs = handler.execQuery(qu);
        while(rs.next()) {
            String name = rs.getString("name");
            String author = rs.getString("author");
            String borrower = rs.getString("borrower");
            if(borrower.equals("none")) {
                books.add(new availableBooks(name, author));
            }
        }
        bookTable.getItems().setAll(books);
    }

    private void initialCol() {
        //
        bookName.setCellValueFactory(new PropertyValueFactory<>("Name"));
        authorName.setCellValueFactory(new PropertyValueFactory<>("Author"));
    }
}
